/* CENGB BOIZ
QuickStudy
Ruel John Cootauco - N01114847
Adam Warrington - N01110575
Acefiel Eroma - N01101571
*/

package cengboiz.quickstudy;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;

public class MainActivity extends AppCompatActivity {

    ImageButton createButton, findButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.mToolbar);
        setSupportActionBar(toolbar);

        createButton = (ImageButton) findViewById(R.id.createsession);
        findButton = (ImageButton) findViewById(R.id.findsession);

        createButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent newActivity = new Intent(MainActivity.this, CreateActivity.class);
                startActivity(newActivity);
            }
        });

        findButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent newActivity = new Intent(MainActivity.this, FindActivity.class);
                startActivity(newActivity);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(final MenuItem item) {
        switch(item.getItemId()) {
            case R.id.app_info:
                new AlertDialog.Builder(this)
                        .setMessage("Running API 21, made by CENG boyz. \n \n QuickStudy is a quick and efficient way to plan out study sessions with friends and classmates. Need study buddies? This app has you covered! ")
                        .setPositiveButton("Continue", null)
                        .create()
                        .show();

                break;
            case R.id.app_contact:
                new AlertDialog.Builder(this)
                        .setMessage("For any questions or inquiries, contact us at, twitter.com/QuickStudy. We always respond to your questions on a timely matter!")
                        .setPositiveButton("Continue", null)
                        .create()
                        .show();
                break;

            case R.id.app_help:
                CharSequence help[] = new CharSequence[] {"Create Session", "Find Session", "Map"};
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                        builder.setItems(help, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                switch(item.getItemId()){
                                    case R.id.createsession:
                                        new AlertDialog.Builder(MainActivity.this)
                                                .setMessage("Create session allows you to create a study session based on your preferences. You pick the subject, location and meet up time.")
                                                .setPositiveButton("Continue", null)
                                                .create()
                                                .show();

                                        break;

                                    case R.id.findsession:
                                        new AlertDialog.Builder(MainActivity.this)
                                                .setMessage("Find session lets you find study sessions based on your preferences.")
                                                .setPositiveButton("Continue", null)
                                                .create()
                                                .show();
                                        break;

                                    case R.id.gmaps:
                                        new AlertDialog.Builder(MainActivity.this)
                                                .setMessage("The map allows you search your area for any study sessions currently active.")
                                                .setPositiveButton("Continue", null)
                                                .create()
                                                .show();

                                        break;

                                    }
                                }

                            }
                        );
                                builder.show();

                break;
        }
        return super.onOptionsItemSelected(item);
    }
}
